import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const skill = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const planPath = path.resolve(process.argv[2] || "film-plan.json");
const project = path.dirname(planPath);
const build = path.join(project, "build");
const output = path.join(project, "out");
const ffOption = process.argv.indexOf("--ffmpeg");
const ffmpeg = ffOption > 0 ? path.resolve(process.argv[ffOption + 1]) : "ffmpeg";
const ffprobe = ffOption > 0 ? path.join(path.dirname(ffmpeg), process.platform === "win32" ? "ffprobe.exe" : "ffprobe") : "ffprobe";
const environment = {...process.env, HYPERFRAMES_SKIP_SKILLS:"1", HYPERFRAMES_TELEMETRY_DISABLED:"1"};
const pathKey = Object.keys(environment).find(key => key.toLowerCase() === "path") || "PATH";
environment[pathKey] = [path.dirname(process.execPath), ...(ffOption > 0 ? [path.dirname(ffmpeg)] : []), environment[pathKey]].filter(Boolean).join(path.delimiter);

function run(file, args, cwd=project) {
  const result = spawnSync(file, args, {cwd, env:environment, encoding:"utf8", windowsHide:true, maxBuffer:32*1024*1024});
  if (result.error || result.status !== 0)
    throw new Error([file, result.error?.message, result.stderr, result.stdout?.slice(-4200)].filter(Boolean).join("\n"));
  return result.stdout;
}
function npmTool(tool, args) {
  // Only fixed tool options are passed to cmd. The project path is cwd.
  return process.platform === "win32"
    ? run(process.env.ComSpec || "cmd.exe", ["/d","/s","/c",[tool+".cmd", ...args].join(" ")], build)
    : run(tool,args,build);
}
function mediaInfo(file) {
  return JSON.parse(run(ffprobe,["-v","error","-show_entries","stream=codec_type,codec_name,width,height:format=duration","-of","json",file]));
}
function projectMedia(source) {
  if (typeof source !== "string" || path.isAbsolute(source)) throw new Error("素材须用项目内的相对路径");
  const real = fs.realpathSync(path.resolve(project, source));
  const relative = path.relative(fs.realpathSync(project), real);
  if (relative === ".." || relative.startsWith(".."+path.sep) || path.isAbsolute(relative))
    throw new Error("素材须位于项目目录");
  return real;
}
function writeJSON(file, object) { fs.writeFileSync(file,JSON.stringify(object,null,2)+"\n"); }
function shortText(value, limit) { return typeof value === "string" && value.length <= limit; }

function makeScore(file, duration, cuts) {
  const rate = 48000;
  const samples = Math.round(rate * duration);
  const pcm = Buffer.alloc(44 + samples * 2);
  pcm.write("RIFF"); pcm.writeUInt32LE(pcm.length-8,4); pcm.write("WAVEfmt ",8);
  pcm.writeUInt32LE(16,16); pcm.writeUInt16LE(1,20); pcm.writeUInt16LE(1,22);
  pcm.writeUInt32LE(rate,24); pcm.writeUInt32LE(rate*2,28); pcm.writeUInt16LE(2,32);
  pcm.writeUInt16LE(16,34); pcm.write("data",36); pcm.writeUInt32LE(samples*2,40);
  const twoPi = 2*Math.PI;
  const notes = [146.83, 174.61, 196, 130.81, 164.81, 207.65];
  let marker = 0;
  for (let i=0; i<samples; i++) {
    const t = i/rate;
    const noteIndex = Math.floor(t*1.5);
    const x = t-noteIndex/1.5;
    const note = notes[noteIndex%notes.length];
    let value = .09*Math.sin(twoPi*note*x)*Math.min(1,x/.025)*Math.exp(-x*6);
    value += .024*Math.sin(twoPi*note*2*x)*Math.min(1,x/.034)*Math.exp(-x*9);
    value += .032*Math.sin(twoPi*73.42*t)*(.65+.25*Math.cos(twoPi*.35*t));
    while(marker<cuts.length-1 && t>=cuts[marker+1]) marker++;
    const hit = t-cuts[marker];
    if(hit>=0&&hit<.45) value+=.062*Math.sin(twoPi*392*hit)*Math.min(1,hit/.024)*Math.exp(-hit*12);
    value *= Math.max(0,Math.min(1,t/.06,(duration-t)/.4));
    pcm.writeInt16LE(Math.round(32767*value),44+i*2);
  }
  fs.writeFileSync(file,pcm);
}

function main() {
  if (Number(process.versions.node.split(".")[0])<22) throw new Error("需要 Node.js 22 或以上");
  run(ffmpeg,["-version"]); run(ffprobe,["-version"]);
  const plan = JSON.parse(fs.readFileSync(planPath,"utf8").replace(/^\uFEFF/,""));
  if (!shortText(plan.brand,36) || !shortText(plan.model,42) || !Array.isArray(plan.shots) ||
      plan.shots.length < 2 || plan.shots.length > 12) throw new Error("需要品牌、型号和 2–12 个镜头");
  let frames=0;
  const shots = plan.shots.map((shot,index) => {
    const shotFrames = Math.round(shot.seconds*30);
    if (!Number.isFinite(shotFrames) || shotFrames<30 || shotFrames>900 ||
        !["hero","detail","action","end"].includes(shot.layout) ||
        !shortText(shot.title,30) || !shortText(shot.copy,55) ||
        !shortText(shot.label??"",16) || !shortText(shot.fact??"",20) ||
        !shortText(shot.factLabel??"",16)) throw new Error("第 "+(index+1)+" 镜的文案、布局或时长无效");
    const original = projectMedia(shot.source);
    const extension = path.extname(original).toLowerCase();
    const photo = [".jpg",".jpeg",".png",".webp"].includes(extension);
    if(!photo && ![".mp4",".mov",".webm",".mkv"].includes(extension)) throw new Error("不支持此素材格式 "+extension);
    const probe = mediaInfo(original);
    if(!probe.streams.some(stream=>stream.codec_type==="video")) throw new Error("无可读画面 "+shot.source);
    const seconds=shotFrames/30, from=shot.from??0, start=frames/30;
    if(!photo && (!Number.isFinite(from) || from<0 || from+seconds>Number(probe.format.duration)+.04))
      throw new Error("视频时码超出素材范围 "+shot.source);
    if(shot.states && (!Array.isArray(shot.states) || shot.states.some((state,i) =>
      !shortText(state.text,18) || !Number.isFinite(state.at) || state.at<0 || state.at>=seconds ||
      (i>0&&state.at<=shot.states[i-1].at)))) throw new Error("状态时间应在镜头内按时间递增");
    frames+=shotFrames;
    return {...shot, original, photo, seconds, from, start, frames:shotFrames, extension};
  });
  const duration=frames/30;
  if(duration>90) throw new Error("当前短片入口最多 90 秒");
  const assetDir = path.join(build,"assets");
  const scenesDir = path.join(build,"src","scenes");
  for(const dir of [assetDir,path.join(assetDir,"vendor"),scenesDir,output]) fs.mkdirSync(dir,{recursive:true});
  console.log("读取素材 "+shots.length+" 段 · 计划成片 "+duration.toFixed(2)+" 秒");
  for(const filename of ["film.js","motion.js","style.css"]) fs.copyFileSync(path.join(skill,"assets","src",filename),path.join(build,"src",filename));
  fs.copyFileSync(path.join(skill,"assets","src","stage.js"),path.join(scenesDir,"01-product.js"));
  const gsap = path.join(build,"node_modules","gsap","dist","gsap.min.js");
  if(!fs.existsSync(gsap)) npmTool("npm",["install","--no-save","--no-audit","--no-fund","--prefer-offline","gsap@3.14.2"]);
  fs.copyFileSync(gsap,path.join(assetDir,"vendor","gsap.min.js"));
  const clips=[];
  for(const [index,shot] of shots.entries()){
    const name="product-"+index+(shot.photo?shot.extension:".mp4");
    const destination=path.join(assetDir,name);
    if(shot.photo) fs.copyFileSync(shot.original,destination);
    else run(ffmpeg,["-v","error","-y","-ss",String(shot.from),"-i",shot.original,"-an","-vf","fps=30,scale=trunc(iw/2)*2:trunc(ih/2)*2,setsar=1","-frames:v",String(shot.frames),"-c:v","libx264","-preset","veryfast","-crf","15","-pix_fmt","yuv420p","-movflags","+faststart",destination]);
    const attributes='class="clip media '+shot.layout+'" src="assets/'+name+'" data-start="'+shot.start.toFixed(3)+'" data-duration="'+shot.seconds.toFixed(3)+'" data-track-index="1"';
    clips.push(shot.photo?'<img '+attributes+' alt="" />':'<video '+attributes+' muted playsinline preload="auto"></video>');
  }
  const publicShots=shots.map(({original,...shot})=>shot);
  writeJSON(path.join(build,"project.json"),{fps:30,bpm:120,beatOffset:0,formats:["wide"],scenes:shots.map((shot,index)=>({id:"shot-"+index,beats:shot.seconds*2}))});
  run(process.execPath,[path.join(skill,"assets","engine","scripts","shells.mjs"),"wide"],build);
  const html=path.join(build,"index.html");
  const data=JSON.stringify({brand:plan.brand,model:plan.model,shots:publicShots}).replaceAll("<","\\u003c");
  fs.writeFileSync(html,fs.readFileSync(html,"utf8")
    .replace("      <section",clips.join("\n")+"\n      <section")
    .replace('    <script src="src/scenes/01-product.js"></script>',"<script>window.PRODUCT_PLAN="+data+';</script>\n    <script src="src/scenes/01-product.js"></script>'));
  const soundtrack=path.join(assetDir,"score.wav");
  makeScore(soundtrack,duration,shots.slice(1).map(shot=>shot.start));
  console.log("本地渲染画面与音乐");
  try {
    const log=npmTool("npx",["--yes","--prefer-offline","hyperframes@0.8.86","render","-q","looks","-o","rendered.mp4"]);
    fs.writeFileSync(path.join(build,"render.log"),log);
  } catch (error) {
    fs.writeFileSync(path.join(build,"render.log"),String(error));
    throw error;
  }
  const final=path.join(output,"产品推广样片.mp4");
  run(ffmpeg,["-v","error","-y","-i",path.join(build,"rendered.mp4"),"-i",soundtrack,"-map","0:v:0","-map","1:a:0","-c:v","copy","-af","loudnorm=I=-20:LRA=7:TP=-2","-ar","48000","-c:a","aac","-b:a","160k","-t",String(duration),"-movflags","+faststart",final]);
  const metadata=mediaInfo(final);
  if (!metadata.streams.some(stream=>stream.codec_name==="h264"&&stream.width===1920&&stream.height===1080) ||
      !metadata.streams.some(stream=>stream.codec_name==="aac") ||
      Math.abs(Number(metadata.format.duration)-duration)>.09) throw new Error("输出视频规格未通过");
  writeJSON(path.join(output,"render-result.json"),{file:final,metadata,shots:publicShots});
  console.log("导出完成  out/产品推广样片.mp4");
}
try {main();} catch(error) {console.error(error.message); process.exitCode=1;}
