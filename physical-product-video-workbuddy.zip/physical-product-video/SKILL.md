---
name: physical-product-video
description: 用真实商品照片、产品规格和实拍使用视频制作不出镜的实物产品推广短片。适用于灯具、配件、五金等产品的图文动效和实际操作展示，交付本地 MP4 和可编辑分镜，无需付费生成模型。
---

# 实物产品推广视频

从用户选定的产品、可使用的真实照片、操作视频和规格开始。只讲当前型号和素材支持的特点。产品图负责外观和结构，实拍负责实际操作与结果。对输入型号、颜色、来源和用过的原始时码做记录；别把照片运镜、其他型号或外部厂商实拍说成自己测试过。

1. 读取素材和产品说明，用 ffprobe 核对素材，抽帧看操作和结果。用首帧给出主题和产品。挑选最短且能看清因果的连续段落。缺证据就缩小文案范围；保持源文件不变。
2. 按 [分镜配置](references/film-plan.md) 在项目里写 `film-plan.json`。可用照片、视频和状态字幕。状态文字按原视频的操作反馈对齐，项目默认横屏。3D 转台可用同型号的已核验文件单独在 Blender 渲染后作为视频素材。
3. 在项目里用 Node 22+ 运行 `node "<skill>/scripts/render.mjs" film-plan.json`。可传 `--ffmpeg "C:/.../ffmpeg.exe"`，同目录应有 ffprobe。脚本用本地 Node、HyperFrames、Chromium 和 FFmpeg，不请求生成式媒体 API。首次需要 npm 依赖及可用的 Chromium。渲染通常需要一分钟左右，等待命令完成。
4. 打开 `out/产品推广样片.mp4`，检查首帧、源实拍、字幕和技术参数。交付 MP4，保留 `film-plan.json`、`build/` 和 `out/render-result.json`。成片只放产品正文和步骤字幕，素材来源及核验状态放项目记录。原始实拍音频默认静音，脚本本地合成音乐。如需配音，使用用户确认的稿件和声音。

镜头时钟来自 Motion Director 的 MIT 场景引擎，许可证见 `LICENSE-Motion-Director.txt`。Windows 试用时可用系统 PowerShell。上传或发布是独立操作，依据用户要求执行。
