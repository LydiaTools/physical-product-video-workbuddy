# 分镜配置

项目目录里用相对路径引用素材。剪辑时只改项目的 JSON 和输出。下面示例中的文件名换成实际素材。

```json
{
  "brand": "品牌",
  "model": "产品型号",
  "shots": [
    {"source":"assets/全景.jpg","seconds":3,"layout":"hero","title":"开场问题","copy":"可见的产品价值"},
    {"source":"assets/细节.jpg","seconds":3,"layout":"detail","label":"结构","title":"操作前看哪里","copy":"说明实际结构","fact":"规格数值","factLabel":"规格名称"},
    {"source":"assets/实拍.mp4","seconds":5,"from":1,"layout":"action","label":"实际操作","title":"操作动作","copy":"说明结果","states":[{"at":0,"text":"初始状态"},{"at":2,"text":"实际结果","active":true}]},
    {"source":"assets/使用.jpg","seconds":3,"layout":"end","title":"使用结果","copy":"品名"}
  ]
}
```

- `seconds` 是成片镜头时长，1–30 秒，按 30fps 对齐。视频 `from` 是原片起点，保持原速。照片接受 JPG、PNG、WebP，视频接受 MP4、MOV、WebM、MKV。
- `layout` 可用 `hero`、`detail`、`action`、`end`。不要求四个布局都使用，取决于真实素材。`action` 使用视频原画幅，`states.at` 是该镜头内部时刻。
- 标题和说明要短。推荐标题不超 16 个中文字符，说明一两句。源视频状态切换时留出前后画面，并检查输出。
- 需要复查规格时回到项目产品说明或品牌原资料。软件安装、素材来源、渲染记录用项目文档留存。
