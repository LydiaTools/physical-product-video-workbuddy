/* Product scene design for the Motion Director clock. */
(function () {
  const { brand, model, shots } = window.PRODUCT_PLAN;
  const escape = value => String(value ?? "").replace(/[&<>"']/g, char =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
  for (const [index, shot] of shots.entries()) {
    MS.scene("shot-" + index, scene => {
      const label = shot.label ? '<div class="label">' + escape(shot.label) + '</div>'
        : '<div class="brand">' + escape(brand) + '</div>';
      const name = '<div class="model">' + escape(model) + '</div>';
      const detail = shot.fact
        ? '<div class="fact"><strong>' + escape(shot.fact) + '</strong><span>' + escape(shot.factLabel) + '</span></div>'
        : '<div class="rule"></div>' + name;
      const states = shot.states ?? [];
      const stateHtml = states.map(state => '<span class="state' + (state.active ? ' active' : '') + '">' + escape(state.text) + '</span>').join('');
      const footer = shot.layout === 'action'
        ? '<div class="states">' + stateHtml + '</div>'
        : detail;
      scene.el.classList.add(shot.layout);
      scene.el.innerHTML = '<div class="block">' + label + '<h1>' + escape(shot.title) +
        '</h1><p class="copy">' + escape(shot.copy) + '</p>' + footer + '</div>' +
        (shot.layout === 'action' ? '<div class="progress"><span></span></div>' : '');
      const rule = scene.$(".rule");
      if (rule) scene.tl.fromTo(rule, {scaleX:.25}, {scaleX:1,duration:.55,ease:"power2.out"}, scene.start);
      const progress = scene.$(".progress span");
      if (progress) scene.tl.fromTo(progress, {scaleX:0}, {scaleX:1,duration:shot.seconds,ease:"none"}, scene.start);
      const nodes = scene.$$(".state");
      for (const [i, state] of states.entries()) {
        scene.tl.set(nodes[i], {opacity:1}, scene.start + state.at);
        if (i > 0) scene.tl.set(nodes[i-1], {opacity:0}, scene.start + state.at);
      }
    });
  }
})();
